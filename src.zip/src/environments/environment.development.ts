export const environment = {
    production: false,
    api_key: 'b9d12b649152f88cd06a32a2ee587da9',
    url_api: 'https://api.themoviedb.org/3/movie/',
     url_movie_api:'https://api.themoviedb.org/3/movie/',
};