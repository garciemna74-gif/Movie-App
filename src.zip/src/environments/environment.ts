export const environment = {
    production: true,
    api_key: 'b9d12b649152f88cd06a32a2ee587da9',
    url_api: 'https://api.themoviedb.org/3/movie/popular',
     url_movie_api:'https://api.themoviedb.org/3/movie/',
};



